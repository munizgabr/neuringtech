<?php

namespace YoastSEO_Vendor\WordProof\SDK\Exceptions;

use Exception;
class ValidationException extends \Exception
{
}
