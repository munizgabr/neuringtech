<?php

namespace YoastSEO_Vendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends \YoastSEO_Vendor\GuzzleHttp\Exception\RequestException
{
}
